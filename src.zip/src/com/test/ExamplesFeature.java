package com.test;

public class ExamplesFeature {
	private final String value;

    public ExamplesFeature(String v) {
        this.value = v;
    }

    public String getValue() {
        return value;
    }
}
